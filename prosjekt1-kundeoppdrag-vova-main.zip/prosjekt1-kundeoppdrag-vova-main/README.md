# Kundeoppdrag

Du skal arbeide som en utvikler som har fått i oppdrag å utvikle en nettside for en kunde. Kunden kan være en virkelig eller fiktiv virksomhet, for eksempel:

- Helpdesk-system for en skole eller bedrift
- IT-sikkerhetsportal
- Inventarsystem
- Reservasjonssystem for utstyr og rom
- Gaming-klubb eller arrangement

Prosjektet trenger ikke å være knyttet til IT. Du kan også velge å lage noe basert på egne interesser, hobbyer eller ting du engasjerer deg i.

## Mål
Gjennom prosjektet skal dere:

- kartlegge behov hos en kunde
- identifisere målgruppe og interessenter
- lage en kravspesifikasjon
- utvikle en prototype
- utvikle en nettside med HTML, CSS og JavaScript
- bruke GitHub til versjonskontroll
- dokumentere arbeidet deres

Prosjektet skal gjennomføres over omtrent fire uker.

## Del 1: behovskartlegging

- Formål
- Mål - minst 3 konkrete mål
- Målgruppe - primær + sekundær
- Interessenter - minst 3 interessenter

## Del 2: kravspesifikasjon

- Funksjonelle krav - minst 8
- Ikke-funksjonelle krav - minst 5
- Avgrensninger
- Begrunnelse - beskriv hvordan kravene dekker behovene til målgruppen

## Del 3: prototype

Dere kan f.eks. bruke Figma eller Canva. Prototypen skal inneholde:

- Nettsidekart
- Wireframes - minst 3
- Begrunnelse - forklar valg av layout, navigasjon, plassering av innhold, farger og målgruppetilpasning

## Del 4: utvikling

- Skal være utviklet med HTML, CSS og JavaScript.
- Skal inneholde minst 4 sider eller én nettside med flere tydelige seksjoner.
- Skal være responsiv og fungere på mobil og PC.
- Skal følge kravene i kravspesifikasjonen.

## Del 5: Refleksjonsrapport

Skriv en kort refleksjon (ca. 0,5-1 side).

Beskriv:

- Hva lærte du gjennom prosjektet?
- Hvilke utfordringer møtte du?
- Hvordan påvirket kravspesifikasjonen arbeidet?
- Hva ville du gjort annerledes neste gang?

## Skal leveres:

GitHub-repo som inneholder:

- kildekode (HTML, CSS og JavaScript)
- kravspesifikasjon
- prototype
- refleksjonsrapport
- Evt. Figma-lenke / Canva-lenke

## Vurderingskriterier

| Område                                | Lav måloppnåelse                                                                                         | Middels måloppnåelse                                                                                         | Høy måloppnåelse                                                                                                            |
| ------------------------------------- | ------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------- |
| **Behovskartlegging**                 | Har beskrevet formål, målgruppe og behov, men beskrivelsene er korte eller mangler noen detaljer.             | Har tydelig beskrevet formål, målgruppe og behov. Viser forståelse for hvem løsningen er laget for.    | Har grundig beskrevet formål, målgruppe, behov og interessenter. Viser god forståelse for sammenhengen mellom behov og løsning. |
| **Kravspesifikasjon**                 | Har formulert noen funksjonelle og ikke-funksjonelle krav, men flere krav er uklare eller vanskelige å teste. | Har formulert relevante funksjonelle og ikke-funksjonelle krav som i hovedsak er tydelige og testbare. | Har formulert tydelige, realistiske og testbare krav som er godt begrunnet ut fra behovskartleggingen.                          |
| **Prototype og design**               | Har laget en enkel prototype som viser hovedideen til løsningen.                                              | Har laget en prototype som viser struktur, navigasjon og viktige designelementer.                      | Har laget en gjennomarbeidet prototype og begrunner designvalgene ut fra målgruppens behov.                                     |
| **HTML**                              | Nettsiden har grunnleggende struktur, men inneholder feil eller mangler.                                      | Nettsiden har en ryddig struktur og bruker relevante HTML-elementer korrekt.                           | Nettsiden har en godt gjennomtenkt struktur og viser svært god forståelse av semantisk HTML.                                    |
| **CSS**                               | Har brukt CSS til å style nettsiden, men designet er lite gjennomført eller mangler responsivitet.            | Har laget et helhetlig design og nettsiden fungerer på ulike skjermstørrelser.                         | Har laget et profesjonelt, gjennomført og responsivt design som er godt tilpasset målgruppen.                                   |
| **JavaScript**                        | Har implementert enkle JavaScript-funksjoner som delvis fungerer som planlagt.                                | Har implementert relevante JavaScript-funksjoner som fungerer godt og støtter kravene til løsningen.   | Har implementert flere relevante JavaScript-funksjoner og viser god forståelse av programmeringslogikk og DOM-manipulering.     |
| **GitHub og arbeidsprosess**          | Har opprettet repository og gjort noen commits underveis.                                                     | Har brukt GitHub gjennom hele prosjektet med jevnlige commits og ryddig struktur.                      | Har brukt GitHub aktivt og systematisk med gode commit-meldinger og tydelig arbeidsprosess.                                     |
| **Sammenheng mellom krav og løsning** | Noen deler av løsningen kan knyttes til kravspesifikasjonen.                                                  | De fleste funksjonene i løsningen kan spores tilbake til kravspesifikasjonen.                          | Hele løsningen bygger tydelig på kravspesifikasjonen, og design- og kodevalg kan begrunnes ut fra kravene.                      |
| **Refleksjonsrapport**                | Beskriver kort hva som er gjort i prosjektet.                                                                 | Reflekterer over arbeidsprosess, utfordringer og valg som er gjort.                                    | Viser god innsikt i egen læring, vurderer styrker og svakheter ved løsningen og foreslår forbedringer.                          |


