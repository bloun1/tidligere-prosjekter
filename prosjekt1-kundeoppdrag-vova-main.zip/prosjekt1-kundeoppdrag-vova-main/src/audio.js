//Den her filen spurt jeg KI å lage for meg fordi hadde ikke tid til å lage den selv.

function clampVol(value, fallback = 0.8) {
  return typeof value === 'number' && value >= 0 && value <= 100
    ? value / 100
    : fallback;
}

const PuzzleAudio = {
  settings: loadSettings(),
  cache: {},

  file(name) {
    return 'src/assets/audio/' + name + '.mp3';
  },

  base(name) {
    if (!this.cache[name]) {
      const audio = new Audio(this.file(name));
      audio.preload = 'auto';
      this.cache[name] = audio;
    }
    return this.cache[name];
  },

  volume(name) {
    return clampVol(this.settings.sound) * clampVol(this.settings[name]);
  },

  play(name, mult = 1) {
    try {
      const node = this.base(name).cloneNode();
      node.volume = Math.max(0, Math.min(1, this.volume(name) * mult));
      node.play().catch(() => {});
    } catch (err) {}
  },

  wireSettings() {
    if (!document.getElementById('sound-slider')) return;

    const sliders = [
      ['sound-slider', 'sound'],
      ['click-slider', 'click'],
      ['start-slider', 'start'],
      ['win-slider', 'win'],
    ];
    for (const [id, key] of sliders) {
      const slider = document.getElementById(id);
      slider.value = this.settings[key] ?? 80;
      slider.addEventListener('input', () => {
        this.settings[key] = Number(slider.value);
        saveSettings(this.settings);
      });
      slider.addEventListener('change', () => this.play(key === 'sound' ? 'click' : key));
    }

    const tilesBtn = document.getElementById('tiles-toggle');
    const renderToggle = () => {
      tilesBtn.textContent = this.settings.tiles ? 'On' : 'Off';
      tilesBtn.classList.toggle('off', !this.settings.tiles);
    };
    renderToggle();
    tilesBtn.addEventListener('click', () => {
      this.settings.tiles = !this.settings.tiles;
      saveSettings(this.settings);
      renderToggle();
      this.play('click', 0.5);
    });
  },
};

document.addEventListener('click', (e) => {
  if (e.target.closest('.btn')) PuzzleAudio.play('click');
});

PuzzleAudio.wireSettings();