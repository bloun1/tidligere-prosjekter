//Konverterer millisekunder til et lesbart tidsformat (MM:SS:SS)
function formatTime(ms) { 
  const totalCs = Math.floor(ms / 10);
  const cs = totalCs % 100;
  const s = Math.floor(totalCs / 100) % 60;
  const m = Math.floor(totalCs / 6000);
  return (
    String(m).padStart(2, '0') + ':' +
    String(s).padStart(2, '0') + ':' +
    String(cs).padStart(2, '0')
  );
}

// Hovedfunksjonen: oppretter brettet, holder på tilstanden og starter spillet.
function initGame(n) {
  const board = document.getElementById('board');
  const timerEl = document.getElementById('timer');
  const movesEl = document.getElementById('moves');
  const lastEl = document.getElementById('last-time');
  const bestEl = document.getElementById('best-time');
  const overlay = document.getElementById('win-overlay');
  const winTimeEl = document.getElementById('win-time');
  const winMovesEl = document.getElementById('win-moves');
  const winBadge = document.getElementById('win-badge');
  const resetBtn = document.getElementById('reset-btn');
  const playAgainBtn = document.getElementById('play-again-btn');

  const size = n * n;
  const level = String(n);
  const records = loadRecords();
  if (!records[level]) records[level] = { last: null, best: null };

 // Opprettelse av brikker i HTML og definisjon av løst tilstand.
  const solvedState = () => Array.from({ length: size }, (_, i) => (i + 1) % size);

  let state = solvedState();
  let moves = 0;
  let started = false;
  let finished = false;
  let startTime = 0;
  let finalMs = 0;
  let tickId = null;

  const tiles = [];
  for (let v = 0; v < size; v++) {
    const el = document.createElement('div');
    el.className = 'tile' + (v === 0 ? ' tile--blank' : '');
    if (v !== 0) el.textContent = v;
    el.dataset.value = v;
    board.appendChild(el);
    tiles[v] = el;
  }

  // Sender posisjonen til brikken til CSS-variabler for visning.
  const setTilePos = (value, pos) => {
    tiles[value].style.setProperty('--r', pos / n | 0);
    tiles[value].style.setProperty('--c', pos % n);
  };

  const rowOf = (pos) => Math.floor(pos / n);
  const colOf = (pos) => pos % n;
  const isNeighbour = (a, b) =>
    Math.abs(rowOf(a) - rowOf(b)) + Math.abs(colOf(a) - colOf(b)) === 1;

  function render() {
    const blank = state.indexOf(0);
    state.forEach((value, pos) => {
      setTilePos(value, pos);
      if (value !== 0) {
        tiles[value].classList.toggle('tile--movable', isNeighbour(pos, blank));
      }
    });
  }

  // Starter timeren når spillet starter, oppdaterer den hvert 50. millisekund, og stopper den når spillet er ferdig.
  function startTimer() {
    started = true;
    startTime = performance.now();
    tickId = setInterval(updateTimer, 50);
  }

  function updateTimer() {
    timerEl.textContent = formatTime(performance.now() - startTime);
  }

  function stopTimer() {
    clearInterval(tickId);
    finalMs = performance.now() - startTime;
    timerEl.textContent = formatTime(finalMs);
  }
// Flytter brikken til den tomme plassen hvis den er nabo, oppdaterer tilstanden og sjekker om spillet er løst.
  function moveAt(pos) {
    const blank = state.indexOf(0);
    if (finished || !isNeighbour(pos, blank)) return;
    [state[pos], state[blank]] = [state[blank], state[pos]];
    moves++;
    movesEl.textContent = moves;
    if (!started) startTimer();
    render();
    if (PuzzleAudio.settings.tiles) PuzzleAudio.play('click', 0.5);
    if (isSolved()) onWin();
  }

  // Blander brettet ved å gjøre tilfeldige lovlige trekk (garanterer at puslespillet kan løses).
  function shuffle() {
    state = solvedState();
    let blank = state.indexOf(0);
    let prevBlank = -1;
    for (let i = 0; i < size * 60; i++) {
      const options = [blank - n, blank + n, blank - 1, blank + 1].filter(
        (p) => p >= 0 && p < size && p !== prevBlank && isNeighbour(p, blank)
      );
      const next = options[Math.floor(Math.random() * options.length)];
      [state[blank], state[next]] = [state[next], state[blank]];
      prevBlank = blank;
      blank = next;
    }
    if (isSolved()) {
      [state[0], state[1]] = [state[1], state[0]];
    }
  }

  // Sjekker om spillet er løst, stopper timeren og lagrer rekorder.
  const isSolved = () => state.every((v, i) => v === (i + 1) % size);

  // Viser siste og beste tid for gjeldende nivå.
  function showRecords() {
    lastEl.textContent = records[level].last
      ? formatTime(records[level].last.timeMs)
      : '--:--:--';
    bestEl.textContent = records[level].best
      ? formatTime(records[level].best.timeMs)
      : '--:--:--';
  }

  function onWin() {
    finished = true;
    stopTimer();
    const rec = {
      timeMs: Math.round(finalMs),
      moves: moves,
      date: new Date().toISOString(),
    };
    records[level].last = rec;
    const newBest =
      !records[level].best || rec.timeMs < records[level].best.timeMs;
    if (newBest) records[level].best = rec;
    saveRecords(records);

    winTimeEl.textContent = formatTime(rec.timeMs);
    winMovesEl.textContent = moves === 1 ? '1 move' : moves + ' moves';
    winBadge.style.display = newBest ? 'inline-block' : 'none';
    overlay.classList.add('show');
    showRecords();
    PuzzleAudio.play('win');
  }

    // Tilbakestiller spillet til starttilstand, blander brikkene og starter på nytt.
  function reset() {
    finished = false;
    started = false;
    clearInterval(tickId);
    moves = 0;
    movesEl.textContent = '0';
    timerEl.textContent = '00:00:00';
    overlay.classList.remove('show');
    shuffle();
    render();
    PuzzleAudio.play('start');
  }

  board.addEventListener('click', (e) => {
    const tile = e.target.closest('.tile');
    if (!tile) return;
    moveAt(state.indexOf(Number(tile.dataset.value)));
  });

  window.addEventListener('keydown', (e) => {
    const delta = { ArrowUp: n, ArrowDown: -n, ArrowLeft: 1, ArrowRight: -1 }[e.key];
    if (delta === undefined) return;
    e.preventDefault();
    const blank = state.indexOf(0);
    if (delta === 1 && colOf(blank) === n - 1) return;
    if (delta === -1 && colOf(blank) === 0) return;
    const target = blank + delta;
    if (target >= 0 && target < size) moveAt(target);
  });

  resetBtn.addEventListener('click', reset);
  playAgainBtn.addEventListener('click', reset);

  reset();
  showRecords();
}

  // Starter spillet når DOM-en er lastet, sjekker om det kreves et tidligere nivå for å spille, og initialiserer spillet med riktig størrelse.
document.addEventListener('DOMContentLoaded', () => {
  const board = document.getElementById('board');
  if (!board) return;

  const requires = Number(board.dataset.requires || 0);
  if (requires) {
    const gate = loadRecords()[String(requires)];
    if (!gate || !gate.last) {
      location.replace('index.html');
      return;
    }
  }
  initGame(Number(board.dataset.size));
});