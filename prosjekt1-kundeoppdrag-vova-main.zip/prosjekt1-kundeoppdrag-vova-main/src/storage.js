//Den her filen spurt jeg KI å lage for meg fordi hadde ikke tid til å lage den selv. Den lagrer og henter data fra localStorage.

const RECORDS_KEY = '15-puzzle-records';
const SETTINGS_KEY = '15-puzzle-settings';

const DEFAULT_SETTINGS = { sound: 80, click: 80, start: 80, win: 80, tiles: true };

function readJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (err) {
    return fallback;
  }
}

function writeJSON(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function loadRecords() {
  return readJSON(RECORDS_KEY, {});
}

function saveRecords(records) {
  writeJSON(RECORDS_KEY, records);
}

function loadSettings() {
  return { ...DEFAULT_SETTINGS, ...readJSON(SETTINGS_KEY, {}) };
}

function saveSettings(settings) {
  writeJSON(SETTINGS_KEY, settings);
}