Del 1: Behovskartlegging

Formål 
Formålet med prosjektet er å utvikle en engasjerende og visuelt gjennomført digital versjon av det klassiske 15-spillet, der brukeren tas med inn i et unikt univers inspirert av mørke, uutforskede grotter og underjordiske huler. Spilleren skal gjennom en intuitiv startside og jevne animasjoner få en stemningsfull opplevelse av å bevege seg dypere inn i undergrunnen, med mulighet for å bryne seg på et ekstra utfordrende «24-spill» som låses opp ved fullført nivå.

Mål
1. Design og visuell identitet: Utvikle et helhetlig design med mørke farger, egne teksturer og grotte-inspirerte elementer i Figma, som deretter implementeres i koden ved hjelp av HTML, CSS og JavaScript.
2. Funksjonalitet og spillflyt: Implementere full funksjonalitet for 15-spillet, inkludert tilfeldig blanding av blokker med jevne animasjoner, startside, tidtaker som starter ved første trekk, samt knapper for tilbakestilling og tilbakegang til hovedmenyen.
3. Ekstra nivå (24-spill): Utvikle og integrere et vanskeligere «24-spill» som låses opp etter fullført 15-spill, inkludert en advarselmelding dersom brukeren prøver å låse det opp for tidlig, samt en visuell forsterkning av at spilleren beveger seg dypere ned.
Målgruppe
• Primærmålgruppe: Gamere og personer som liker hjernetrim, logiske oppgaver og klassiske flisespill (15-spill), og som setter pris på stemningsfull, mørk og tematisk visuell stil.
• Sekundærmålgruppe: Lærere, sensorer og medelever i IT-faget som skal vurdere prosjektet basert på funksjonalitet, struktur, HTML/CSS/JS-bruk og versjonskontroll via GitHub.
Interessenter
1. Utvikleren (du selv): Som har ansvar for hele prosessen fra skisse i Figma til ferdig kode, versjonskontroll i GitHub og oppnåelse av læringsmålene.
2. Lærer/Faglærer: Som veileder og vurderer om prosjektet oppfyller kompetansemålene og kravene i oppgaven (behovskartlegging, krav, koding og dokumentasjon).
3. Sluttbrukerne/Spillerne: Som skal teste og bruke nettsiden, og som forventer et responsivt, feilfritt og visuelt tiltalende spill.

Del 2: Kravspesifikasjon

Funksjonelle krav
1. Nettsiden skal ha en startside med en startknapp for å starte spillet.
2. 15-spillet skal automatisk stokke blokkene tilfeldig ved start og ved trykk på tilbakestillingsknappen.
3. Flytting av blokker skal skje med jevne, visuelle animasjoner.
4. En tidtaker skal starte automatisk ved spillerens første trekk.
5. Spillet skal registrere når 15-spillet er fullført, slik at det oppnås en seierstilstand.
6. Det skal finnes en knapp underveis for å gå tilbake til hovedmenyen.
7. Det skal finnes et låst «24-spill»-nivå som blir tilgjengelig først etter at 15-spillet er fullført.
8. Dersom brukeren prøver å åpne det andre nivået (24-spill) uten å ha fullført det første, skal det dukke opp en advarsel på skjermen.
Ikke-funksjonelle krav
1. Visuell stil: Designet skal konsekvent bruke mørke farger og egne bildebaserte teksturer for å skape en atmosfære av underjordiske grotter.
2. Teknologi: Nettsiden skal være kodet i ren HTML, CSS og JavaScript.
3. Versjonskontroll: All koding og fremdrift skal dokumenteres og lagres fortløpende ved hjelp av Git og GitHub.
4. Brukervennlighet: Grensesnittet skal være intuitivt og lett forståelig for brukeren uten behov for en ekstern bruksanvisning.
5. Visuell progresjon: Designet på nivå to («24-spill») skal fremstå mørkere for å understreke at karakteren beveger seg dypere inn i undergrunnen.
Avgrensninger
1. Spillet vil ikke ha noen database- eller serverløsning for lagring av globale highscore-lister (topplister) for flere brukere; tidtakeren gjelder kun for den aktive økten i nettleseren.
2. Det blir ikke laget avanserte lydeffekter eller bakgrunnsmusikk i denne versjonen, fokuset holdes på layout, animasjoner og spilllogikk.
3. Utviklingen begrenser seg til det oppgitte tidsrommet på ca. fire uker, noe som betyr at 24-spill-nivået er en opsjon («hvis det blir tid»).

Begrunnelse
Kravene dekker behovene til målgruppen ved å kombinere en engasjerende spillopplevelse med et sterkt visuelt konsept (grotte-tema). De funksjonelle kravene sørger for at selve kjernefunksjonaliteten (blanding, flytting, tidtaker, menyer og nivå-låsing) fungerer feilfritt, slik at spilleren får en komplett opplevelse. De ikke-funksjonelle kravene sikrer at nettsiden opprettholder den spesifikke atmosfæren og oppfyller de faglige kravene til koding (HTML/CSS/JS) og versjonskontroll (GitHub). Avgrensningene sørger for at prosjektet er realistisk å fullføre innen tidsrammen på fire uker.


